module ActiveAdmin
  class Component < Arbre::Component

  end
end
