module ActiveAdmin
  VERSION = '1.0.0.pre'
end
