beforeEach(function() {
  window.inject = $.jasmine.inject;
});
