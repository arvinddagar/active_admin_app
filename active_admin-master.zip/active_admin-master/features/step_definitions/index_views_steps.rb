When /^I click "(.*?)"$/ do |link|
  click_link(link)
end
