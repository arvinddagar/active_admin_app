# Custom Pages

If you have data you want on a standalone page that isn't tied to a resource,
custom pages provide you with a familiar syntax and feature set:

* a menu item
* sidebars
* action items
* page actions

## Create a new Page

Creating a page is as simple as calling `register_page`:

```ruby
# app/admin/calendar.rb
ActiveAdmin.register_page "Calendar" do
  content do
    para "Hello World"
  end
end
```

Anything rendered within `content` will be the main content on the page.
Partials behave exactly the same way as they do for resources:

```ruby
# app/admin/calendar.rb
ActiveAdmin.register_page "Calendar" do
  content do
    render partial: 'calendar'
  end
end

# app/views/admin/calendar/_calendar.html.arb
table do
  thead do
    tr do
      %w[Sunday Monday Tuesday Wednesday Thursday Friday Saturday].each &method(:th)
    end
  end
  tbody do
    # ...
  end
end
```

## Customize the Menu

See the [Menu](2-resource-customization.md#customize-the-menu) documentation.

## Add a Sidebar

See the [Sidebars](7-sidebars.md) documentation.

## Add an Action Item

Just like other resources, you can add action items. The difference here being that
`:only` and `:except` don't apply because there's only one page it could apply to.

```ruby
action_item do
  link_to "View Site", "/"
end
```

## Add a Page Action

Page actions are custom controller actions (which mirror the resource DSL for the same feature).

```ruby
page_action :add_event, method: :post do
  # ...
  redirect_to admin_calendar_path, notice: "Your event was added"
end

action_item do
  link_to "Add Event", admin_calendar_add_event_path, method: :post
end
```

This defines the route `/admin/calendar/add_event` which can handle HTTP POST requests.

Clicking on the action item will reload page and display the message "Your event was added"
