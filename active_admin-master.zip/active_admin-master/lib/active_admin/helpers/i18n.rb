module ActiveAdmin
  module Helpers
    module I18n
      PLURAL_MANY_COUNT = 2.1
    end
  end
end
