# ActiveRecord-specific plugins should be required here

require 'active_admin/orm/active_record/comments'
