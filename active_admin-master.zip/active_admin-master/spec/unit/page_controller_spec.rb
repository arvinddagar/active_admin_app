require 'spec_helper'

describe ActiveAdmin::PageController do
  let(:controller) { ActiveAdmin::PageController.new }
end
