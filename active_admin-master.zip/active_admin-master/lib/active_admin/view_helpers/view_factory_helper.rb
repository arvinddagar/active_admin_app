module ActiveAdmin
  module ViewHelpers
    module ViewFactoryHelper

      def view_factory
        active_admin_namespace.view_factory
      end

    end
  end
end
