# Mongoid-specific plugins should be required here
